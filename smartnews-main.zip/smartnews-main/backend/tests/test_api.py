"""
API endpoint tests for Smart News backend.
Run from project root: pytest backend/tests/ -v
Or from backend/: pytest tests/ -v
"""
import pytest
from fastapi.testclient import TestClient


def test_root(client: TestClient):
    """Root endpoint returns welcome message."""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert "message" in data
    assert "docs" in data
    assert "version" in data


def test_health(client: TestClient):
    """Health check returns ok and service info."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert "service" in data
    assert "version" in data


def test_articles_list(client: TestClient):
    """Articles endpoint returns list or paginated response."""
    response = client.get("/api/v1/articles/")
    assert response.status_code == 200
    data = response.json()
    assert "articles" in data
    assert isinstance(data["articles"], list)
    assert "total" in data


def test_articles_with_limit(client: TestClient):
    """Articles accepts limit and offset."""
    response = client.get("/api/v1/articles/?limit=5&offset=0")
    assert response.status_code == 200
    data = response.json()
    assert len(data["articles"]) <= 5


def test_trending(client: TestClient):
    """Trending endpoint returns list."""
    response = client.get("/api/v1/trending")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)


def test_news_stats(client: TestClient):
    """News stats returns totals."""
    response = client.get("/news/stats")
    assert response.status_code == 200
    data = response.json()
    assert "total_articles" in data


def test_news_quick_feed(client: TestClient):
    """Quick feed returns list of articles."""
    response = client.get("/news/quick-feed")
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)


def test_signup_creates_user(client: TestClient):
    """Signup creates a new user and returns success."""
    response = client.post(
        "/api/v1/auth/signup",
        json={"username": "testuser_api", "password": "testpass123"},
    )
    # 200 created or 400 if user already exists from previous run
    assert response.status_code in (200, 400)
    data = response.json()
    if response.status_code == 200:
        assert "message" in data


def test_login_fails_bad_password(client: TestClient):
    """Login with wrong password returns 400."""
    response = client.post(
        "/api/v1/auth/login/access-token",
        data={"username": "nobody123", "password": "wrong"},
    )
    assert response.status_code == 400


def test_view_increment_rate_limit(client: TestClient):
    """View count endpoint increments views and is rate-limited."""
    from app.db.session import SessionLocal
    from app.models.article import Article
    from datetime import datetime, timezone
    
    db = SessionLocal()
    try:
        article = Article(
            title="Test Rate Limit Article",
            content="This is content for testing view count rate limit.",
            source="Test Source",
            url="http://example.com/test-view-limit",
            category="Technology",
            publish_date=datetime.now(timezone.utc)
        )
        db.add(article)
        db.commit()
        db.refresh(article)
        article_id = article.id
    finally:
        db.close()

    # Make 10 successful requests
    for i in range(10):
        res = client.post(f"/api/v1/articles/{article_id}/view")
        assert res.status_code == 200
        assert "view_count" in res.json()
        
    # The 11th request must exceed the 10/minute rate limit
    res = client.post(f"/api/v1/articles/{article_id}/view")
    assert res.status_code == 429

