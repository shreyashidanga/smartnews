'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { X, Radio, ChevronRight, Newspaper, Zap, BarChart3 } from 'lucide-react';
import { API_ENDPOINTS } from '../lib/config';
import { safeApiRequest, checkBackendHealth } from '../lib/api';
import { ApiErrorDisplay } from './ErrorBoundary';

interface Stats {
    total_articles: number;
    new_today: number;
    status: string;
}

interface Article {
    title: string;
    source: string;
    url: string;
    publish_date: string;
}

import { UserButton, SignedIn, SignedOut, SignInButton, SignUpButton } from '@clerk/nextjs';

export default function Sidebar({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
    const [stats, setStats] = useState<Stats | null>(null);
    const [quickFeed, setQuickFeed] = useState<Article[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (isOpen) {
            loadData();
        }
    }, [isOpen]);

    async function loadData() {
        setIsLoading(true);
        setError(null);

        try {
            // Fetch stats and quick feed in parallel directly
            const [statsData, feedData] = await Promise.all([
                safeApiRequest<Stats>(API_ENDPOINTS.STATS),
                safeApiRequest<Article[]>(API_ENDPOINTS.QUICK_FEED),
            ]);

            if (statsData) setStats(statsData);
            if (feedData) setQuickFeed(feedData);

            if (!statsData && !feedData) {
                // If both fail, verify health status before setting error
                const isHealthy = await checkBackendHealth();
                if (!isHealthy) {
                    setError('Backend service is currently unavailable');
                } else {
                    setError('Unable to load sidebar data. Please try again.');
                }
            }
        } catch (err) {
            console.error('Error loading sidebar data:', err);
            setError('Failed to connect to the server');
        } finally {
            setIsLoading(false);
        }
    }

    return (
        <>
            {/* Backdrop */}
            <div
                className={`fixed inset-0 bg-black/60 z-[60] transition-opacity duration-500 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
                onClick={onClose}
            />

            {/* Panel */}
            <aside 
                className={`fixed inset-y-0 left-0 w-full max-w-[350px] bg-card z-[70] shadow-2xl transition-all duration-500 ease-in-out border-r-2 border-border text-primary ${
                    isOpen ? 'translate-x-0 opacity-100 pointer-events-auto visible' : '-translate-x-full opacity-0 pointer-events-none invisible'
                }`}
                aria-hidden={!isOpen}
            >
                <div className="flex flex-col h-full uppercase tracking-widest font-black">
                    {/* Header */}
                    <div className="p-6 border-b-2 border-border flex justify-between items-center bg-paper">
                        <span className="text-[11px]">Newsroom Command</span>
                        <button onClick={onClose} className="p-2 hover:bg-primary hover:text-card transition-colors">
                            <X className="w-5 h-5" />
                        </button>
                    </div>

                    <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-8">
                        {/* Account Controls on Mobile */}
                        <section className="p-4 bg-muted/50 border border-border rounded-xl">
                            <h3 className="text-[9px] text-secondary mb-3 flex items-center justify-between">
                                <span>Account & Access</span>
                            </h3>
                            <SignedIn>
                                <div className="flex items-center justify-between gap-4">
                                    <div className="flex items-center gap-2">
                                        <UserButton afterSignOutUrl="/" />
                                        <span className="text-xs font-bold text-primary">Profile</span>
                                    </div>
                                    <div className="flex items-center gap-3 text-xs">
                                        <Link href="/saved" onClick={onClose} className="hover:text-accent font-black hover:underline">SAVED</Link>
                                        <Link href="/admin" onClick={onClose} className="hover:text-accent font-black hover:underline">ADMIN</Link>
                                    </div>
                                </div>
                            </SignedIn>
                            <SignedOut>
                                <div className="flex items-center gap-3">
                                    <SignInButton mode="modal">
                                        <button className="flex-1 py-2 px-3 bg-accent text-white rounded-lg text-xs font-bold text-center">Sign In</button>
                                    </SignInButton>
                                    <SignUpButton mode="modal">
                                        <button className="flex-1 py-2 px-3 border border-border rounded-lg text-xs font-bold text-center hover:bg-muted">Sign Up</button>
                                    </SignUpButton>
                                </div>
                            </SignedOut>
                        </section>
                        {/* Error Display */}
                        {error && (
                            <ApiErrorDisplay error={error} onRetry={loadData} />
                        )}

                        {/* Loading State */}
                        {isLoading && !error && (
                            <div className="flex items-center justify-center py-8">
                                <div className="w-8 h-8 border-4 border-border border-t-accent rounded-full animate-spin"></div>
                            </div>
                        )}

                        {/* 1. Live Ingestion Stats */}
                        <section>
                            <h3 className="text-[10px] text-accent flex items-center gap-2 mb-6">
                                <Radio className="w-3 h-3 animate-pulse" /> 🛰️ Live Ingestion Stats
                            </h3>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="p-4 bg-muted border border-border flex flex-col gap-1">
                                    <span className="text-[9px] text-secondary">Total Processed</span>
                                    <span className="text-2xl font-serif tracking-tighter">{stats?.total_articles || '---'}</span>
                                </div>
                                <div className="p-4 bg-muted border border-border flex flex-col gap-1">
                                    <span className="text-[9px] text-secondary">New Today</span>
                                    <span className="text-2xl font-serif tracking-tighter text-accent">+{stats?.new_today || '---'}</span>
                                </div>
                            </div>
                            <div className="mt-4 flex items-center gap-2 text-[9px] text-secondary">
                                <Zap className="w-3 h-3 text-yellow-500" /> System Status: <span className="text-primary">{stats?.status || 'Syncing...'}</span>
                            </div>
                        </section>

                        {/* 3. Extended Sections */}
                        <section>
                            <h3 className="text-[10px] flex items-center gap-2 mb-6 border-b border-border pb-2">
                                <Newspaper className="w-3 h-3" /> Extended Sections
                            </h3>
                            <div className="flex flex-col gap-4">
                                {[
                                    { name: 'AI & Startups', path: 'AI & Startups' },
                                    { name: 'Environment', path: 'Environment' },
                                    { name: 'Education', path: 'Education' },
                                    { name: 'World', path: 'World' },
                                ].map(section => (
                                    <Link
                                        key={section.name}
                                        href={`/?category=${section.path}`}
                                        onClick={onClose}
                                        className="group flex items-center justify-between text-[13px] hover:text-accent transition-colors"
                                    >
                                        {section.name}
                                        <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                                    </Link>
                                ))}
                            </div>
                        </section>

                        {/* 4. Quick-Feed */}
                        <section>
                            <h3 className="text-[10px] flex items-center gap-2 mb-6 border-b border-border pb-2">
                                <BarChart3 className="w-3 h-3" /> The Quick-Feed (Latest 10)
                            </h3>
                            <div className="flex flex-col gap-6">
                                {quickFeed.map((art, i) => (
                                    <a
                                        key={i}
                                        href={art.url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="group block"
                                    >
                                        <div className="flex items-center gap-2 mb-2">
                                            <span className="text-[8px] px-1 bg-brand text-card">{art.source}</span>
                                            <span className="text-[8px] text-secondary">{new Date(art.publish_date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                        </div>
                                        <h4 className="text-[11px] leading-tight font-bold group-hover:text-accent lowercase normal-case">
                                            {art.title}
                                        </h4>
                                    </a>
                                ))}
                            </div>
                        </section>
                    </div>

                    {/* Footer */}
                    <div className="p-6 border-t border-border text-[9px] text-secondary text-center">
                        The Smart News Engine v2.1 • 2026 Ready
                    </div>
                </div>
            </aside>
        </>
    );
}
